


/*------ SYSDBA 09/05/2018 16:46:15 --------*/

COMMENT ON COLUMN TBCFOP.CFOP_TIPO IS
'Tipo:
0 - A Definir
1 - Entrada
2 - Saida';

